﻿using CSharpMethod.Models;

Console.WriteLine("Class:");

#region Anonimous object
//var obj1 = new
//{
//   name = "Elxan",
//   surname = "Memmedli",
//   age = 26,
//   phone = "+994505005050"
//};

//var obj2 = new
//{
//    name = "Aydan",
//    surname = "Memmedli",
//    age = 19
//};

//Console.WriteLine(obj1.age);
#endregion

#region Class
//instance
Student stu1=new Student();
stu1.Name = "Elxan";
stu1.Age = 26;
stu1.Surname = "Memmedli";
stu1.Info();

Student stu2 = new("Aydan", "Memmedli",19);
stu2.Info();

Teacher t1 = new()
{
    Name = "Kamran",
    Age = 33,
    Surname = "Jabiyev"
};
t1.Info();
#region Constructor

#endregion
#endregion
