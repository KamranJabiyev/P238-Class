﻿namespace CSharpMethod.Models;

internal class Student:Person
{
    //constructor - yalniz instance aldiqda call olunur,
    //object instance alinanda ilk ishe dushen code bloku
    //return type yoxdur
    //C# class adi ile eyni addadir!
    public Student()
    {
        Console.WriteLine("ctor1");
    }

    public Student(string Name, string surname) : this()
    {
        this.Name = Name;
        Surname = surname;
        Console.WriteLine("ctor-2");
    }
    public Student(string Name,string surname,int age):this(Name, surname)
    {
        Age= age;
        Console.WriteLine("ctor-3");
    }
}
