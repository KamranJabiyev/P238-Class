﻿namespace CSharpMethod.Models;

internal class Teacher:Person
{

}
