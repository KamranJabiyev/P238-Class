﻿namespace CSharpMethod.Models;

internal class Person
{
    public string Name; //field
    public string Surname;
    public int Age;
    public Person()
    {
        Console.WriteLine("Person is created");
    }
    //method
    public void Info()
    {
        Console.WriteLine($"{Surname} {Name}");
    }
}
